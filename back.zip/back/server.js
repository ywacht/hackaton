import express from 'express'
import { createUnauthenticatedClient } from '@interledger/open-payments'

const app = express()
app.use(express.json())
const port = process.env.PORT || 3000

// Crear cliente de forma asíncrona dentro de una función
let client;

async function initializeClient() {
  try {
    console.log('Inicializando cliente Interledger...')
    
    // Crear el cliente sin validación estricta primero
    client = await createUnauthenticatedClient({
      validateResponses: false // Desactivar validación por ahora
    })
    
    console.log('Cliente Interledger inicializado correctamente')
    console.log('Métodos disponibles:', Object.keys(client))
    
    // Verificar que los métodos necesarios existen
    console.log('✅ Todos los métodos necesarios están disponibles')
    
  } catch (error) {
    console.error('❌ Error inicializando cliente:', error)
    console.error('Detalles del error:', error.stack)
    // No salir del proceso, continuar sin el cliente
    client = null
  }
}

// Endpoint para crear un Incoming Payment
app.post('/pago', async (req, res) => {
  try {
    console.log('🔍 Iniciando proceso de creación de pago...')
    
    // Validar que el cliente esté inicializado
    if (!client) {
      console.error('❌ Cliente no inicializado')
      return res.status(500).json({
        success: false,
        error: 'Cliente Interledger no inicializado. Verifica la configuración del servidor.',
        suggestion: 'Reinicia el servidor e intenta nuevamente'
      })
    }

    console.log('✅ Cliente disponible, métodos:', Object.keys(client))

    // Obtener datos del body de la request o usar valores por defecto
    const {
      assetCode = 'USD',
      assetScale = 2,
      value = '1000',
      descripcion = 'Pago de prueba'
    } = req.body

    console.log('📝 Datos del pago:', { assetCode, assetScale, value, descripcion })

    // (a) Resolver el wallet address
    console.log('🔍 Resolviendo wallet address...')
    
    if (!client.walletAddress || typeof client.walletAddress.get !== 'function') {
      throw new Error('Método walletAddress.get no disponible en el cliente')
    }
    
    const walletAddress = await client.walletAddress.get({
      url: 'https://ilp.interledger-test.dev/pablog'
    })
    
    console.log('✅ Wallet address obtenido:', {
      id: walletAddress.id,
      authServer: walletAddress.authServer,
      resourceServer: walletAddress.resourceServer
    })

    // (b) Solicitar un grant de incoming-payment
    console.log('🔐 Solicitando grant...')
    
    if (!client.grant || typeof client.grant.request !== 'function') {
      throw new Error('Método grant.request no disponible en el cliente')
    }
    
    const grantRequest = {
      access_token: {
        access: [
          {
            type: 'incoming-payment',
            actions: ['create', 'read']
          }
        ]
      },
      interact: {
        start: ['redirect'],
        finish: {
          method: 'redirect',
          uri: 'https://example.com/callback',
          nonce: Math.random().toString(36).substring(2, 15)
        }
      },
      client: {
        display: {
          name: 'Mi App de Pagos'
        }
      }
    }
    
    console.log('📤 Enviando solicitud de grant a:', walletAddress.authServer)
    console.log('📋 Datos del grant:', JSON.stringify(grantRequest, null, 2))
    
    const incomingPaymentGrant = await client.grant.request(
      {
        url: walletAddress.authServer
      },
      grantRequest
    )

    console.log('📨 Grant recibido:', {
      hasAccessToken: !!incomingPaymentGrant.access_token,
      hasInteract: !!incomingPaymentGrant.interact,
      hasContinue: !!incomingPaymentGrant.continue
    })

    // Verificar si necesitamos interactuar (autorización)
    if (incomingPaymentGrant.interact) {
      console.log('🔐 Autorización requerida')
      return res.json({
        success: false,
        requiresAuth: true,
        authUrl: incomingPaymentGrant.interact.redirect,
        message: 'Se requiere autorización. Visita la URL para continuar.',
        continueUrl: incomingPaymentGrant.continue?.uri,
        continueToken: incomingPaymentGrant.continue?.access_token?.value,
        grant: incomingPaymentGrant
      })
    }

    // (c) Crear el Incoming Payment si ya tenemos el token
    console.log('💳 Creando incoming payment...')
    
    if (!client.incomingPayment || typeof client.incomingPayment.create !== 'function') {
      throw new Error('Método incomingPayment.create no disponible en el cliente')
    }
    
    const paymentData = {
      walletAddress: walletAddress.id,
      incomingAmount: {
        assetCode: assetCode,
        assetScale: parseInt(assetScale),
        value: value.toString()
      },
      metadata: {
        externalRef: `#INV${Date.now()}`,
        description: descripcion
      }
    }
    
    console.log('📋 Datos del incoming payment:', JSON.stringify(paymentData, null, 2))
    
    const incomingPayment = await client.incomingPayment.create(
      {
        url: walletAddress.resourceServer,
        accessToken: incomingPaymentGrant.access_token.value
      },
      paymentData
    )

    console.log('✅ Incoming Payment creado exitosamente:', incomingPayment.id)

    res.json({ 
      success: true, 
      incomingPayment,
      paymentPointer: incomingPayment.id,
      amount: {
        value: value,
        assetCode: assetCode,
        assetScale: assetScale
      },
      message: 'Pago creado correctamente'
    })

  } catch (error) {
    console.error('❌ Error detallado creando pago:')
    console.error('Nombre del error:', error.constructor.name)
    console.error('Mensaje:', error.message)
    console.error('Stack:', error.stack)
    
    // Información adicional si está disponible
    if (error.response) {
      console.error('Response status:', error.response.status)
      console.error('Response data:', error.response.data)
    }
    
    // Proporcionar más detalles del error
    const errorResponse = {
      success: false,
      error: error.message,
      type: error.constructor.name,
      timestamp: new Date().toISOString()
    }

    // Agregar detalles específicos si están disponibles
    if (error.response) {
      errorResponse.httpStatus = error.response.status
      errorResponse.httpStatusText = error.response.statusText
      errorResponse.responseData = error.response.data
    }

    // Sugerencias basadas en el tipo de error
    if (error.message.includes('grant')) {
      errorResponse.suggestion = 'Verifica que el cliente Interledger esté correctamente inicializado y que los métodos grant estén disponibles'
    } else if (error.message.includes('walletAddress')) {
      errorResponse.suggestion = 'Verifica que la URL del wallet address sea correcta y esté disponible'
    } else if (error.message.includes('not available')) {
      errorResponse.suggestion = 'Problema con la inicialización del cliente. Verifica la instalación de @interledger/open-payments'
    }

    res.status(500).json(errorResponse)
  }
});

// Endpoint para continuar con la autorización (callback)
app.post('/continue-payment', async (req, res) => {
  try {
    const { continueUrl, continueToken, interact_ref } = req.body

    if (!continueUrl || !continueToken) {
      return res.status(400).json({
        error: 'Se requieren continueUrl y continueToken'
      })
    }

    // Continuar con el grant
    const continuedGrant = await client.grant.continue({
      url: continueUrl,
      accessToken: continueToken
    }, {
      interact_ref: interact_ref
    })

    res.json({
      success: true,
      grant: continuedGrant,
      message: 'Ahora puedes crear el incoming payment con este grant'
    })

  } catch (error) {
    console.error('Error continuando grant:', error)
    res.status(500).json({ 
      success: false, 
      error: error.message 
    })
  }
})

// Endpoint de salud con más información
app.get('/health', (req, res) => {
  const clientStatus = {
    initialized: !!client,
    methods: client ? Object.keys(client) : [],
    hasWalletAddress: !!(client && client.walletAddress),
    hasGrant: !!(client && client.grant),
    hasIncomingPayment: !!(client && client.incomingPayment)
  }
  
  res.json({ 
    status: 'OK',
    timestamp: new Date().toISOString(),
    client: clientStatus,
    nodejs: process.version,
    platform: process.platform
  })
})

// Endpoint de información
app.get('/', (req, res) => {
  res.json({
    message: 'Servidor Interledger Open Payments',
    endpoints: {
      'POST /pago': 'Crear incoming payment',
      'POST /continue-payment': 'Continuar autorización',
      'GET /health': 'Estado del servidor'
    },
    example: {
      assetCode: "USD",
      assetScale: 2,
      value: "1000",
      descripcion: "Pago de prueba"
    }
  })
})

// Inicializar servidor
async function startServer() {
  try {
    console.log('🚀 Iniciando servidor Interledger...')
    
    // Primero verificar que tenemos las dependencias
    try {
      const openPayments = await import('@interledger/open-payments')
      console.log('✅ Dependencia @interledger/open-payments cargada')
      console.log('📦 Versión disponible:', openPayments.version || 'desconocida')
    } catch (importError) {
      console.error('❌ Error importando @interledger/open-payments:', importError.message)
      console.error('💡 Ejecuta: npm install @interledger/open-payments')
      process.exit(1)
    }
    
    await initializeClient()
    
    app.listen(port, () => {
      console.log(`🚀 Servidor corriendo en http://localhost:${port}`)
      console.log(`📝 Documentación en http://localhost:${port}`)
      console.log(`💚 Estado del servidor: http://localhost:${port}/health`)
      console.log(`🔧 Cliente inicializado: ${client ? '✅ SÍ' : '❌ NO'}`)
      
      if (client) {
        console.log(`📋 Métodos disponibles: ${Object.keys(client).join(', ')}`)
      }
    })
  } catch (error) {
    console.error('❌ Error iniciando servidor:', error)
    console.error('🔍 Stack completo:', error.stack)
    process.exit(1)
  }
}

startServer()